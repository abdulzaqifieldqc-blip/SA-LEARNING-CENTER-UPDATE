package com.salearningcenter.admin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://abdulzaqifieldqc-blip.github.io/SA-LEARNING-CENTER-UPDATE/admin.html";
    private WebView webView;
    private FrameLayout root;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            // Keep the WebView inside the system-bar-safe content area.
            // This prevents fixed HTML headers/footers from being drawn
            // underneath the Android status/navigation bars.
            window.setDecorFitsSystemWindows(true);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            window.setNavigationBarColor(Color.BLACK);
        }
        if (Build.VERSION.SDK_INT >= 23) {
            window.setStatusBarColor(Color.WHITE);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        // Do not manually add system-bar padding here. With decorFitsSystemWindows
        // enabled, Android supplies a safe content area to the WebView itself.
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(webView);
        setContentView(root);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setSupportZoom(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                applyChatSafeArea(view);
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl(APP_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }


    /**
     * Keep the Chat Online composer above the fixed HTML bottom navigation.
     * The HTML page is remote, so this small WebView-side fix only applies
     * while #adminQuickChat is present and visible. It does not move the
     * admin bottom navigation itself.
     */
    private void applyChatSafeArea(WebView view) {
        String js = "(function(){" +
                "var chat=document.getElementById('adminQuickChat');" +
                "if(!chat)return;" +
                "var style=document.getElementById('androidChatSafeAreaFix');" +
                "if(!style){" +
                "style=document.createElement('style');" +
                "style.id='androidChatSafeAreaFix';" +
                "style.textContent=" +
                "'#adminQuickChat{padding-bottom:120px!important;box-sizing:border-box!important;}'+" +
                "'#adminQuickChat input,#adminQuickChat textarea{scroll-margin-bottom:130px!important;}';" +
                "document.head.appendChild(style);" +
                "}" +
                "function fix(){" +
                "var c=document.getElementById('adminQuickChat');" +
                "if(!c)return;" +
                "var fields=c.querySelectorAll('input,textarea');" +
                "fields.forEach(function(el){" +
                "var p=el;" +
                "for(var i=0;i<5&&p;i++,p=p.parentElement){" +
                "var pos=getComputedStyle(p).position;" +
                "if(pos==='fixed'||pos==='sticky'){" +
                "p.style.bottom='100px';" +
                "p.style.zIndex='100001';" +
                "break;" +
                "}" +
                "}" +
                "});" +
                "}" +
                "fix();" +
                "setTimeout(fix,300);" +
                "setTimeout(fix,1000);" +
                "})();";
        view.evaluateJavascript(js, null);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }
}
