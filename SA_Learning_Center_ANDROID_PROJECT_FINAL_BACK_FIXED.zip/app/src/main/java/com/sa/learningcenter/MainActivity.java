package com.sa.learningcenter;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private final Handler backHandler = new Handler(Looper.getMainLooper());
    private boolean waitingForSecondHomeBack = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(
                    WebView view, android.webkit.WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");

        // Native Android Back behavior:
        // 1) Any non-Home screen -> Home.
        // 2) Home + first Back -> do nothing.
        // 3) Home + second Back within 2 seconds -> exit the APK.
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                goHomeOrExit();
            }
        });
    }

    private void goHomeOrExit() {
        if (webView == null) return;

        // The HTML app is a single-page app and keeps its current screen in `state.screen`.
        // Ask the WebView which screen is currently displayed instead of relying on WebView
        // history, which would not reliably represent the app's internal navigation.
        webView.evaluateJavascript(
                "(typeof state !== 'undefined' && state && state.screen) ? String(state.screen) : 'home'",
                value -> {
                    String screen = value == null ? "home" : value.replace("\\\"", "");
                    boolean isHome = "home".equals(screen);

                    if (!isHome) {
                        waitingForSecondHomeBack = false;
                        backHandler.removeCallbacksAndMessages(null);
                        // Return to the app Home without touching login, localStorage, or Supabase.
                        webView.evaluateJavascript(
                                "(typeof goHome === 'function') ? goHome() : null", null);
                        return;
                    }

                    if (!waitingForSecondHomeBack) {
                        // First Back on Home: deliberately consume the event and do nothing.
                        waitingForSecondHomeBack = true;
                        backHandler.postDelayed(() -> waitingForSecondHomeBack = false, 2000);
                    } else {
                        // Second Back on Home within 2 seconds: close the Activity/APK.
                        waitingForSecondHomeBack = false;
                        backHandler.removeCallbacksAndMessages(null);
                        finish();
                    }
                });
    }

    @Override
    protected void onDestroy() {
        backHandler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
