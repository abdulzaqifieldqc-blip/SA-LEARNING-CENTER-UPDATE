package com.salearningcenter.admin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    // Admin HTML tetap berasal dari repository. Perubahan di sini hanya menangani
    // safe-area Android agar header/footer tidak tertutup system bars.
    private static final String APP_URL = "https://abdulzaqifieldqc-blip.github.io/SA-LEARNING-CENTER-UPDATE/admin.html";
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            // Android 15/target 35 menggunakan edge-to-edge. Jangan mematikan
            // edge-to-edge; kita berikan inset secara eksplisit ke halaman WebView.
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.BLACK);
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            );
        } else {
            window.setStatusBarColor(Color.WHITE);
            window.setNavigationBarColor(Color.BLACK);
            if (Build.VERSION.SDK_INT >= 23) {
                window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setSupportZoom(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsets wi = insets;
                top = wi.getInsets(WindowInsets.Type.statusBars()).top;
                bottom = wi.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            applyAdminSafeArea(top, bottom);
            return insets;
        });

        if (savedInstanceState == null) {
            webView.loadUrl(APP_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void applyAdminSafeArea(int top, int bottom) {
        if (webView == null) return;

        // Hanya menambahkan ruang aman pada Admin Dashboard dan elemen fixed yang
        // memang terlihat pada screenshot. Tidak mengubah data, menu, atau fungsi.
        String js = "javascript:(function(){" +
                "var s=document.getElementById('__androidAdminSafeAreaV1');" +
                "if(!s){s=document.createElement('style');s.id='__androidAdminSafeAreaV1';document.head.appendChild(s);}" +
                "s.textContent=" +
                "'" +
                "#adminPanelOverlay{padding-top:" + top + "px!important;box-sizing:border-box!important;}" +
                "#adminBottomNav{bottom:" + Math.max(8, bottom + 8) + "px!important;}" +
                "#adminQuickChat{bottom:" + Math.max(88, bottom + 88) + "px!important;}" +
                "#adminChatOverlay{padding-top:" + Math.max(10, top + 10) + "px!important;padding-bottom:" + Math.max(10, bottom + 10) + "px!important;box-sizing:border-box!important;}" +
                "#adminChatPopupV1{bottom:" + Math.max(84, bottom + 84) + "px!important;}" +
                "';" +
                "document.documentElement.style.setProperty('--android-safe-top','" + top + "px');" +
                "document.documentElement.style.setProperty('--android-safe-bottom','" + bottom + "px');" +
                "})()";
        webView.evaluateJavascript(js, null);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }
}
