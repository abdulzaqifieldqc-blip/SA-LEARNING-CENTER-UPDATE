package com.sa.learningcenter;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private final Handler backHandler = new Handler(Looper.getMainLooper());
    private boolean waitingForSecondHomeBack = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(
                    WebView view, android.webkit.WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                handleBack();
            }
        });
    }

    private void handleBack() {
        if (webView == null) return;

        webView.evaluateJavascript(
                "(typeof state !== 'undefined' && state) ? String(state.screen || 'home') : 'home'",
                value -> {
                    String screen = value == null ? "home" : value.replace("\"", "");
                    boolean isHome = "home".equals(screen);

                    if (!isHome) {
                        waitingForSecondHomeBack = false;
                        backHandler.removeCallbacksAndMessages(null);

                        // Return to the existing Home state without touching login/session data.
                        webView.evaluateJavascript(
                                "(typeof goHome === 'function') ? goHome() : null", null);
                        return;
                    }

                    // Home: first Back is consumed; second Back within 2 seconds exits.
                    if (!waitingForSecondHomeBack) {
                        waitingForSecondHomeBack = true;
                        backHandler.postDelayed(
                                () -> waitingForSecondHomeBack = false, 2000);
                    } else {
                        waitingForSecondHomeBack = false;
                        backHandler.removeCallbacksAndMessages(null);
                        finish();
                    }
                });
    }

    @Override
    protected void onDestroy() {
        backHandler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
