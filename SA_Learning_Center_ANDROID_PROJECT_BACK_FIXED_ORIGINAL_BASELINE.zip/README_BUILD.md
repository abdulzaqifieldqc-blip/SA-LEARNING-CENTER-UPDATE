# SA Learning Center Android

Project Android WebView untuk membungkus HTML terakhir menjadi aplikasi Android.

## Build APK
1. Buka folder project ini dengan Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih Build > Build APK(s).
4. APK debug akan berada di:
   app/build/outputs/apk/debug/app-debug.apk

HTML aplikasi berada di:
app/src/main/assets/index.html

Data aplikasi seperti localStorage tetap dikelola oleh WebView.
