SA Learning Center Android Wrapper

This project wraps the existing GitHub Pages master HTML without modifying it.
App name: SA Learning Center
App icon: app_icon.jpg (the supplied image)
Web source: https://abdulzaqifieldqc-blip.github.io/SA-LEARNING-CENTER-UPDATE/

Build task: :app:assembleDebug
