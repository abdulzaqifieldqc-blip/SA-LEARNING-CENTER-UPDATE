SA Learning Center Admin - Android Project

Purpose:
Separate Admin APK wrapper for the fixed Admin HTML.

Web URL used by this APK:
https://abdulzaqifieldqc-blip.github.io/SA-LEARNING-CENTER-UPDATE/admin.html

IMPORTANT BEFORE BUILD:
1. Upload the fixed Admin HTML to the GitHub repository root.
2. Rename the uploaded file exactly to: admin.html
3. Confirm GitHub Pages serves:
   https://abdulzaqifieldqc-blip.github.io/SA-LEARNING-CENTER-UPDATE/admin.html
4. Then build this Android project in Android Studio.

App identity:
- Name: SA Learning Center Admin
- Application ID: com.salearningcenter.admin
- Version: 1.0
- Icon: Akulaku Finance logo supplied by user

The APK is separate from the SA APK but both can use the same Supabase backend through their respective HTML pages.
